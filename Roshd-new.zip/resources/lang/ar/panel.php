<?php

return [
    'site_title' => 'رشد',
];
