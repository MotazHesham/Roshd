<?php

return [
    'site_title' => 'ROSHD',
];
